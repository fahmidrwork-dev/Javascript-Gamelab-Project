let plus = tambah (6,3);
let min = kurang (6,3);
let multiple = kali (6,3);
let divide = bagi (6,3);
function tambah(p1, p2) 
{
    return p1 + p2 ; // lengkapi bagian baris ini
}
function kurang(p1, p2)
{
    return p1 - p2; 
    // lengkapi bagian baris ini
}
function kali(p1, p2) 
{
    return p1 * p2; ; // lengkapi bagian baris ini
}
function bagi(p1, p2)
{
    return p1 / p2; ; // lengkapi bagian baris ini
}
    
console.log ( plus );
console.log( min );
console.log( multiple );
console.log( divide );
